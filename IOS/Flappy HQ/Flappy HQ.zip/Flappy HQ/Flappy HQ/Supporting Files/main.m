//
//  main.m
//  Flappy HQ
//
//  Created by 权一恒 on 28/05/14.
//  Copyright HenryQuan 2014年. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
