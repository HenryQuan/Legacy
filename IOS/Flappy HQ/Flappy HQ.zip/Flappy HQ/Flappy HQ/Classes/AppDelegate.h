//
//  AppDelegate.h
//  Flappy HQ
//
//  Created by 权一恒 on 28/05/14.
//  Copyright HenryQuan 2014年. All rights reserved.
//
// -----------------------------------------------------------------------

#import "cocos2d.h"

@interface AppDelegate : CCAppDelegate
@end
